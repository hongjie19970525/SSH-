package com.bank.domain;

public class TradeInfo {
	private String datatime;
	
	private String userNO;
	private int money;
	private int balance=0;
	private int id;
	private String trade;
	 
	public int getMoney(){
		return money;
	}
	public void setMoney(int money){
		this.money=money;
	}
	
	public int getId(){
		return id;
	}
	
	public void setId(int id){
		this.id=id;
	}
	
	public String getDatatime(){
		return datatime;
	}
	
	public void setDatatime(String datatime){
		this.datatime=datatime;
	}
	
	public String getUserNO(){
		return userNO;
	}
	
	public void setUserNO(String userNO){
		this.userNO=userNO;
	}
	public String getTrade(){
		return trade;
	}
	public void setTrade(String trade){
		this.trade=trade;
	}
	public int getBalance(){
		return balance;
	}
	public void setBalance(int balance){
		this.balance=balance;
	}
	
	
	
	
	
	
	
	
}
